<?php
    // Un array avec les info de connections. 
    $configArray = [
        'host' => 'localhost',
        'dbnom' => 'inventaire',
        'port' => 3306,
        'charset' => 'utf8',
        'user' => 'root',
        'password' => '',
    ];
?>